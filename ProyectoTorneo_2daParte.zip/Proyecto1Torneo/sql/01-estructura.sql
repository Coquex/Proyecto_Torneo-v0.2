SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS torneo CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE torneo;

-- Se mantienen los nombres de la tabla y los campos del proyecto inicial.
CREATE TABLE IF NOT EXISTS Users (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS equipos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    escudo_url VARCHAR(1000) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    usuario_id INT NOT NULL,
    estado ENUM('PENDIENTE','APROBADO','RECHAZADO') NOT NULL DEFAULT 'PENDIENTE',
    FOREIGN KEY (usuario_id) REFERENCES Users(Id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS torneos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    imagen_url VARCHAR(1000) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    premio DECIMAL(12,2) NOT NULL,
    estado ENUM('ACTIVO','FINALIZADO','CANCELADO') NOT NULL DEFAULT 'ACTIVO',
    campeon_id INT NULL,
    -- NULL permite conservar varios torneos finalizados; el valor 1 solo puede aparecer una vez.
    activo_unico TINYINT GENERATED ALWAYS AS (IF(estado = 'ACTIVO', 1, NULL)) STORED UNIQUE,
    FOREIGN KEY (campeon_id) REFERENCES equipos(id),
    CHECK (fecha_fin >= fecha_inicio),
    CHECK (premio >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS torneo_equipos (
    torneo_id INT NOT NULL,
    equipo_id INT NOT NULL,
    PRIMARY KEY (torneo_id, equipo_id),
    FOREIGN KEY (torneo_id) REFERENCES torneos(id),
    FOREIGN KEY (equipo_id) REFERENCES equipos(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rondas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    torneo_id INT NOT NULL,
    numero INT NOT NULL,
    nombre VARCHAR(40) NOT NULL,
    UNIQUE (torneo_id, numero),
    UNIQUE (id, torneo_id),
    FOREIGN KEY (torneo_id) REFERENCES torneos(id),
    CHECK (numero BETWEEN 1 AND 4)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS partidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    torneo_id INT NOT NULL,
    ronda_id INT NOT NULL,
    numero INT NOT NULL,
    local_id INT NULL,
    visitante_id INT NULL,
    goles_local INT NULL,
    goles_visitante INT NULL,
    ganador_id INT NULL,
    estado ENUM('PENDIENTE','FINALIZADO') NOT NULL DEFAULT 'PENDIENTE',
    siguiente_partido_id INT NULL,
    puesto_siguiente TINYINT NULL,
    UNIQUE (ronda_id, numero),
    UNIQUE (id, torneo_id),
    FOREIGN KEY (ronda_id, torneo_id) REFERENCES rondas(id, torneo_id),
    FOREIGN KEY (torneo_id, local_id) REFERENCES torneo_equipos(torneo_id, equipo_id),
    FOREIGN KEY (torneo_id, visitante_id) REFERENCES torneo_equipos(torneo_id, equipo_id),
    FOREIGN KEY (torneo_id, ganador_id) REFERENCES torneo_equipos(torneo_id, equipo_id),
    FOREIGN KEY (siguiente_partido_id, torneo_id) REFERENCES partidos(id, torneo_id),
    CHECK (local_id IS NULL OR visitante_id IS NULL OR local_id <> visitante_id),
    CHECK (goles_local IS NULL OR goles_local >= 0),
    CHECK (goles_visitante IS NULL OR goles_visitante >= 0),
    CHECK (puesto_siguiente IS NULL OR puesto_siguiente IN (1,2))
) ENGINE=InnoDB;

-- Esta fila permite coordinar aprobaciones y creación del torneo dentro de una transacción.
CREATE TABLE IF NOT EXISTS control_torneo (id INT PRIMARY KEY) ENGINE=InnoDB;
INSERT IGNORE INTO control_torneo (id) VALUES (1);
