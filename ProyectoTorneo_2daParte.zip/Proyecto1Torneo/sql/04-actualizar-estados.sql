-- Ejecutar una vez si ya creaste la base con una versión anterior del proyecto.
-- Conserva los torneos y sus datos; agrega el estado CANCELADO.
USE torneo;
ALTER TABLE torneos
    MODIFY COLUMN estado ENUM('ACTIVO','FINALIZADO','CANCELADO') NOT NULL DEFAULT 'ACTIVO';
