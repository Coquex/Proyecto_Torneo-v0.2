package my.webapp.torneo.database;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/** Clase de conexión del proyecto inicial de lucia. */
public class Database {

    public static Connection getConnection() throws SQLException {
        String ruta = System.getProperty("torneo.config");
        if (ruta == null || ruta.isBlank()) {
            ruta = System.getProperty("user.home") + "/.torneo/db.properties";
        }
        Properties datos = new Properties();
        try (Reader archivo = Files.newBufferedReader(Path.of(ruta), StandardCharsets.UTF_8)) {
            datos.load(archivo);
        } catch (IOException e) {
            throw new SQLException("No se pudo leer la configuración local de MySQL.", "08001");
        }
        for (String campo : new String[]{"db.url", "db.user", "db.password"}) {
            if (datos.getProperty(campo) == null || datos.getProperty(campo).isBlank()) {
                throw new SQLException("Faltan datos en la configuración de MySQL.", "08001");
            }
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Falta el conector MySQL.", "08001");
        }
        return DriverManager.getConnection(datos.getProperty("db.url"),
                datos.getProperty("db.user"), datos.getProperty("db.password"));
    }
}
