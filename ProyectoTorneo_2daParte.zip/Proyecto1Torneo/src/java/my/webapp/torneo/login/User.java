package my.webapp.torneo.login;

/** Modelo del proyecto inicial de lucia. */
public class User {
    private final int Id;
    private final String Name;
    private final String Email;
    private final String Password;
    private final String Role;

    public User(int Id, String Name, String Email, String Password, String Role) {
        this.Id = Id;
        this.Name = Name;
        this.Email = Email;
        this.Password = Password;
        this.Role = Role;
    }

    public int getId() { return Id; }
    public String getName() { return Name; }
    public String getEmail() { return Email; }
    public String getPassword() { return Password; }
    public String getRole() { return Role; }
    public boolean isAdmin() { return "ADMIN".equals(Role); }
}
