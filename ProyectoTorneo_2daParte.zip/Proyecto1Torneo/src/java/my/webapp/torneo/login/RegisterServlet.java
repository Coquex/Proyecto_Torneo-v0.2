package my.webapp.torneo.login;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Locale;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import my.webapp.torneo.util.Web;

/** Registro del proyecto inicial de lucia. */
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/register.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.tokenValido(request)) { response.sendError(403); return; }
        String name = Web.dato(request, "txtname");
        String email = Web.dato(request, "txtemail").toLowerCase(Locale.ROOT);
        String password = request.getParameter("txtpwd");
        if (name.isEmpty() || name.length() > 120) {
            error(request, response, "El nombre es obligatorio y admite hasta 120 caracteres."); return;
        }
        if (email.length() > 254 || !email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")) {
            error(request, response, "Ingresa un correo electrónico válido."); return;
        }
        if (password == null || password.isBlank() || password.length() < 10 || password.length() > 128) {
            error(request, response, "La contraseña debe tener entre 10 y 128 caracteres."); return;
        }
        try {
            UserDao dao = new UserDao();
            if (dao.EmailExists(email)) {
                error(request, response, "Ese correo ya está registrado."); return;
            }
            dao.Register(new User(0, name, email, password, "USER"));
            Web.redirigir(request, response, "/login.jsp?success=registered");
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) { error(request, response, "Ese correo ya está registrado."); }
            else { Web.errorBD(response, e); }
        }
    }

    private void error(HttpServletRequest request, HttpServletResponse response, String mensaje) throws ServletException, IOException {
        request.setAttribute("error", mensaje);
        response.setStatus(422);
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }
}
