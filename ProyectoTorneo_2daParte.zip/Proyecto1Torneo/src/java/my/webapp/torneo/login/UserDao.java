package my.webapp.torneo.login;

import my.webapp.torneo.database.Database;
import my.webapp.torneo.util.PasswordUtil;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** DAO del proyecto inicial de lucia. */
public class UserDao {

    public User ValidateLogin(String email, String password) throws SQLException {
        String sql = "SELECT Id, Name, Email, Password, Role FROM Users WHERE Email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) { return null; }
                String guardada = rs.getString("Password");
                boolean antigua = !guardada.startsWith("pbkdf2-sha256$");
                boolean valida = antigua
                        ? MessageDigest.isEqual(guardada.getBytes(StandardCharsets.UTF_8), password.getBytes(StandardCharsets.UTF_8))
                        : PasswordUtil.verificar(password, guardada);
                if (!valida) { return null; }
                int id = rs.getInt("Id");
                if (antigua) {
                    // Conserva las cuentas iniciales y protege su clave al ingresar por primera vez.
                    try (PreparedStatement cambio = conn.prepareStatement("UPDATE Users SET Password = ? WHERE Id = ?")) {
                        cambio.setString(1, PasswordUtil.crearHash(password));
                        cambio.setInt(2, id);
                        cambio.executeUpdate();
                    }
                }
                // El objeto que se guarda en sesión no contiene la contraseña.
                return new User(id, rs.getString("Name"), rs.getString("Email"), null, rs.getString("Role"));
            }
        }
    }

    public boolean Register(User user) throws SQLException {
        String sql = "INSERT INTO Users (Name, Email, Password, Role) VALUES (?, ?, ?, 'USER')";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, PasswordUtil.crearHash(user.getPassword()));
            return ps.executeUpdate() == 1;
        }
    }

    public boolean EmailExists(String email) throws SQLException {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT Id FROM Users WHERE Email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
}
