package my.webapp.torneo.login;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Locale;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import my.webapp.torneo.util.Web;

/** Controlador de acceso del proyecto inicial de lucia. */
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.tokenValido(request)) { response.sendError(403); return; }
        if ("salir".equals(request.getParameter("action"))) {
            request.getSession().invalidate();
            Web.redirigir(request, response, "/login.jsp");
            return;
        }
        String email = Web.dato(request, "txtemail").toLowerCase(Locale.ROOT);
        String password = request.getParameter("txtpwd");
        if (email.length() > 254 || email.isEmpty() || password == null || password.isEmpty() || password.length() > 128) {
            error(request, response, "Ingresa el correo y la contraseña.");
            return;
        }
        try {
            User user = new UserDao().ValidateLogin(email, password);
            if (user == null) {
                error(request, response, "Correo o contraseña incorrectos.");
                return;
            }
            HttpSession anterior = request.getSession(false);
            if (anterior != null) { anterior.invalidate(); }
            HttpSession session = request.getSession(true);
            session.setAttribute("User", user);
            Web.token(session);
            Web.redirigir(request, response, "/inicio.jsp");
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void error(HttpServletRequest request, HttpServletResponse response, String mensaje) throws ServletException, IOException {
        request.setAttribute("error", mensaje);
        response.setStatus(422);
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }
}
