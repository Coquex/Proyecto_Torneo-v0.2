package my.webapp.torneo.login;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SessionFilter implements Filter {
    @Override
    public void doFilter(ServletRequest entrada, ServletResponse salida, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) entrada;
        HttpServletResponse response = (HttpServletResponse) salida;
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("X-Content-Type-Options", "nosniff");
        String ruta = request.getServletPath();
        boolean publica = ruta.startsWith("/assets/") || ruta.equals("/login.jsp") || ruta.equals("/register.jsp")
                || ruta.equals("/LoginServlet") || ruta.equals("/RegisterServlet");
        if (!ruta.startsWith("/assets/")) { response.setHeader("Cache-Control", "no-store"); }
        if (!publica) {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("User") == null) {
                response.sendRedirect(request.getContextPath() + "/login.jsp"); return;
            }
        }
        chain.doFilter(request, response);
    }
}
