package my.webapp.torneo.util;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PasswordUtil {
    private static final int ITERACIONES = 600000;

    public static String crearHash(String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] hash = calcular(password, salt, ITERACIONES);
        return "pbkdf2-sha256$" + ITERACIONES + "$"
                + Base64.getEncoder().encodeToString(salt) + "$"
                + Base64.getEncoder().encodeToString(hash);
    }

    public static boolean verificar(String password, String guardada) {
        try {
            String[] partes = guardada.split("\\$");
            if (partes.length != 4 || !"pbkdf2-sha256".equals(partes[0])) { return false; }
            int vueltas = Integer.parseInt(partes[1]);
            if (vueltas < ITERACIONES || vueltas > 1000000) { return false; }
            byte[] salt = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            return salt.length == 16 && esperado.length == 32
                    && MessageDigest.isEqual(esperado, calcular(password, salt, vueltas));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] calcular(String password, byte[] salt, int vueltas) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, vueltas, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("No se pudo proteger la contraseña.", e);
        } finally {
            spec.clearPassword();
        }
    }
}
