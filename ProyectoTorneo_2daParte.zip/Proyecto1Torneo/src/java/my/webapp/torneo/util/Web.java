package my.webapp.torneo.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.SQLException;
import java.util.Base64;
import java.util.logging.Logger;
import my.webapp.torneo.login.User;

public class Web {
    public static String texto(Object valor) {
        if (valor == null) { return ""; }
        return valor.toString().replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
    }

    public static String dato(HttpServletRequest request, String nombre) {
        String valor = request.getParameter(nombre);
        return valor == null ? "" : valor.trim();
    }

    public static String token(HttpSession session) {
        String token = (String) session.getAttribute("csrf");
        if (token == null) {
            byte[] bytes = new byte[32];
            new SecureRandom().nextBytes(bytes);
            token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            session.setAttribute("csrf", token);
        }
        return token;
    }

    public static boolean tokenValido(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        String enviado = request.getParameter("csrf");
        Object esperado = session == null ? null : session.getAttribute("csrf");
        return esperado instanceof String && enviado != null && MessageDigest.isEqual(
                ((String) esperado).getBytes(StandardCharsets.UTF_8), enviado.getBytes(StandardCharsets.UTF_8));
    }

    public static User usuario(HttpServletRequest request) {
        return (User) request.getSession().getAttribute("User");
    }

    public static boolean admin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User user = usuario(request);
        if (user == null || !user.isAdmin()) {
            response.sendError(403);
            return false;
        }
        return true;
    }

    public static int id(String valor) {
        try {
            int id = Integer.parseInt(valor);
            if (id > 0) { return id; }
        } catch (NumberFormatException e) { }
        throw new IllegalArgumentException("Identificador inválido.");
    }

    public static boolean imagenValida(String valor) {
        if (valor == null || valor.length() > 1000) { return false; }
        if (valor.matches("assets/imagenes/(escudo|torneo)\\.svg")) { return true; }
        try {
            URI uri = URI.create(valor);
            return ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                    && uri.getHost() != null && uri.getUserInfo() == null;
        } catch (IllegalArgumentException e) { return false; }
    }

    public static String imagen(String contexto, String valor) {
        if (!imagenValida(valor)) { return contexto + "/assets/imagenes/escudo.svg"; }
        return valor.startsWith("assets/") ? contexto + "/" + valor : valor;
    }

    public static void redirigir(HttpServletRequest request, HttpServletResponse response, String ruta) {
        response.setStatus(303);
        response.setHeader("Location", request.getContextPath() + ruta);
    }

    public static void errorBD(HttpServletResponse response, SQLException e) throws IOException {
        Logger.getLogger("torneo").warning("Error de base de datos. SQLState: " + e.getSQLState());
        response.sendError(503);
    }
}
