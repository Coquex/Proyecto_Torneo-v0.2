package my.webapp.torneo.equipo;

public class Equipo {
    private final int id;
    private final String nombre;
    private final String escudoUrl;
    private final String telefono;
    private final int usuarioId;
    private final String dueno;
    private final String estado;
    private boolean estadoBloqueado;

    public Equipo(int id, String nombre, String escudoUrl, String telefono, int usuarioId, String dueno, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.escudoUrl = escudoUrl;
        this.telefono = telefono;
        this.usuarioId = usuarioId;
        this.dueno = dueno;
        this.estado = estado;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEscudoUrl() { return escudoUrl; }
    public String getTelefono() { return telefono; }
    public int getUsuarioId() { return usuarioId; }
    public String getDueno() { return dueno; }
    public String getEstado() { return estado; }
    public boolean isEstadoBloqueado() { return estadoBloqueado; }
    public void setEstadoBloqueado(boolean bloqueado) { this.estadoBloqueado = bloqueado; }
}
