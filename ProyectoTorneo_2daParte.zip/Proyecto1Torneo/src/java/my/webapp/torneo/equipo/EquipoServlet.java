package my.webapp.torneo.equipo;

import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import my.webapp.torneo.login.User;
import my.webapp.torneo.util.Web;

public class EquipoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = Web.dato(request, "action");
        if ("nuevo".equals(action)) {
            request.getRequestDispatcher("/WEB-INF/views/equipo-form.jsp").forward(request, response);
        } else if (action.isEmpty() || "listar".equals(action)) {
            listar(request, response);
        } else if ("editar".equals(action) || "confirmar".equals(action)) {
            if (!Web.admin(request, response)) { return; }
            try { mostrarGestion(request, response, Web.id(Web.dato(request, "id")), "confirmar".equals(action)); }
            catch (IllegalArgumentException e) { response.sendError(400); }
        } else { response.sendError(404); }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.tokenValido(request)) { response.sendError(403); return; }
        String action = Web.dato(request, "action");
        int id = 0;
        if ("actualizar".equals(action) || "eliminar".equals(action)) {
            if (!Web.admin(request, response)) { return; }
            try { id = Web.id(Web.dato(request, "id")); }
            catch (IllegalArgumentException e) { response.sendError(400); return; }
        }
        try {
            EquipoDao dao = new EquipoDao();
            if ("registrar".equals(action)) {
                dao.registrar(leerFormulario(request, 0, Web.usuario(request).getId()));
                Web.redirigir(request, response, "/EquipoServlet?estado=registrado");
            } else if ("actualizar".equals(action)) {
                Equipo actual = dao.buscar(id);
                if (actual == null) { response.sendError(404); return; }
                if (!dao.actualizar(leerFormulario(request, id, actual.getUsuarioId()), Web.dato(request, "estado"))) {
                    response.sendError(404); return;
                }
                Web.redirigir(request, response, "/EquipoServlet?estado=actualizado");
            } else if ("eliminar".equals(action)) {
                if (!"si".equals(request.getParameter("confirmacion"))) { response.sendError(400); return; }
                if (!dao.eliminar(id)) { response.sendError(404); return; }
                Web.redirigir(request, response, "/EquipoServlet?estado=eliminado");
            } else if ("aprobar".equals(action) || "rechazar".equals(action)) {
                if (!Web.admin(request, response)) { return; }
                dao.cambiarEstado(Web.id(Web.dato(request, "id")), "aprobar".equals(action) ? "APROBADO" : "RECHAZADO");
                Web.redirigir(request, response, "/EquipoServlet?estado=actualizado");
            } else { response.sendError(404); }
        } catch (IllegalArgumentException e) {
            error(request, response, e.getMessage(), action, id);
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062 && ("registrar".equals(action) || "actualizar".equals(action))) {
                error(request, response, "Ya existe un equipo con ese nombre.", action, id);
            } else if (e.getErrorCode() == 1451 && "eliminar".equals(action)) {
                error(request, response, "El equipo pertenece al historial de un torneo y no puede eliminarse todavía.", action, id);
            } else { Web.errorBD(response, e); }
        }
    }

    private Equipo leerFormulario(HttpServletRequest request, int id, int usuarioId) {
        String nombre = Web.dato(request, "nombre");
        String escudo = Web.dato(request, "escudo_url");
        String telefono = Web.dato(request, "telefono");
        if (nombre.isEmpty() || nombre.length() > 100) {
            throw new IllegalArgumentException("El nombre del equipo es obligatorio y admite hasta 100 caracteres.");
        }
        if (!Web.imagenValida(escudo)) { throw new IllegalArgumentException("Ingresa una URL de imagen http o https válida."); }
        if (!telefono.matches("[+0-9 ()-]{8,20}") || telefono.replaceAll("[^0-9]", "").length() < 8) {
            throw new IllegalArgumentException("Ingresa un teléfono válido de 8 a 20 caracteres.");
        }
        return new Equipo(id, nombre, escudo, telefono, usuarioId, null, "PENDIENTE");
    }

    private void mostrarGestion(HttpServletRequest request, HttpServletResponse response, int id, boolean eliminacion) throws ServletException, IOException {
        try {
            EquipoDao dao = new EquipoDao();
            Equipo equipo = dao.buscar(id);
            if (equipo == null) { response.sendError(404); return; }
            request.setAttribute("equipo", equipo);
            request.setAttribute("puedeEliminar", dao.puedeEliminar(id));
            request.getRequestDispatcher(eliminacion ? "/WEB-INF/views/equipo-eliminar.jsp" : "/WEB-INF/views/equipo-editar.jsp").forward(request, response);
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void listar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = Web.usuario(request);
        try {
            request.setAttribute("equipos", new EquipoDao().listar(user.getId(), user.isAdmin()));
            request.getRequestDispatcher("/WEB-INF/views/equipos.jsp").forward(request, response);
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void error(HttpServletRequest request, HttpServletResponse response, String mensaje, String action, int id) throws ServletException, IOException {
        request.setAttribute("error", mensaje);
        response.setStatus(422);
        if ("registrar".equals(action)) { request.getRequestDispatcher("/WEB-INF/views/equipo-form.jsp").forward(request, response); }
        else if ("actualizar".equals(action) || "eliminar".equals(action)) { mostrarGestion(request, response, id, "eliminar".equals(action)); }
        else { listar(request, response); }
    }
}
