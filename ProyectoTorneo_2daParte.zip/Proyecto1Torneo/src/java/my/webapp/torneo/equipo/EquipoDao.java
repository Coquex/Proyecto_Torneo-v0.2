package my.webapp.torneo.equipo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import my.webapp.torneo.database.Database;

public class EquipoDao {
    private static final String CONSULTA = "SELECT e.*, u.Name AS dueno, EXISTS(SELECT 1 FROM torneo_equipos te"
            + " JOIN torneos t ON t.id=te.torneo_id WHERE te.equipo_id=e.id AND t.estado='ACTIVO') AS bloqueado"
            + " FROM equipos e JOIN Users u ON u.Id=e.usuario_id";

    public List<Equipo> listar(int usuarioId, boolean administrador) throws SQLException {
        String sql = CONSULTA
                + (administrador ? "" : " WHERE e.estado='APROBADO' OR e.usuario_id=?") + " ORDER BY e.id";
        List<Equipo> equipos = new ArrayList<>();
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (!administrador) { ps.setInt(1, usuarioId); }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) { equipos.add(leerGestion(rs)); }
            }
        }
        return equipos;
    }

    public Equipo buscar(int id) throws SQLException {
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(CONSULTA + " WHERE e.id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? leerGestion(rs) : null; }
        }
    }

    public boolean puedeEliminar(int id) throws SQLException {
        String sql = "SELECT NOT EXISTS(SELECT 1 FROM torneo_equipos WHERE equipo_id=?)"
                + " AND NOT EXISTS(SELECT 1 FROM torneos WHERE campeon_id=?) AS permitido";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() && rs.getBoolean("permitido"); }
        }
    }

    public boolean actualizar(Equipo equipo, String estadoSolicitado) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                bloquearPreparacion(conn);
                String estadoActual;
                boolean bloqueado;
                String consulta = "SELECT e.estado, EXISTS(SELECT 1 FROM torneo_equipos te JOIN torneos t ON t.id=te.torneo_id"
                        + " WHERE te.equipo_id=e.id AND t.estado='ACTIVO') AS bloqueado FROM equipos e WHERE e.id=? FOR UPDATE";
                try (PreparedStatement ps = conn.prepareStatement(consulta)) {
                    ps.setInt(1, equipo.getId());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        estadoActual = rs.getString("estado");
                        bloqueado = rs.getBoolean("bloqueado");
                    }
                }
                String estadoFinal;
                if (bloqueado) {
                    if (!estadoSolicitado.isEmpty() && !estadoActual.equals(estadoSolicitado)) {
                        throw new IllegalArgumentException("El estado está bloqueado porque el equipo participa en un torneo activo.");
                    }
                    estadoFinal = estadoActual;
                } else {
                    if (!"APROBADO".equals(estadoSolicitado) && !"RECHAZADO".equals(estadoSolicitado)) {
                        throw new IllegalArgumentException("Selecciona el estado Aprobado o Rechazado.");
                    }
                    estadoFinal = estadoSolicitado;
                }
                String sql = "UPDATE equipos SET nombre=?, escudo_url=?, telefono=?, estado=? WHERE id=?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, equipo.getNombre());
                    ps.setString(2, equipo.getEscudoUrl());
                    ps.setString(3, equipo.getTelefono());
                    ps.setString(4, estadoFinal);
                    ps.setInt(5, equipo.getId());
                    ps.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                bloquearPreparacion(conn);
                try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM equipos WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                    }
                }
                String vinculados = "SELECT t.estado FROM torneo_equipos te JOIN torneos t ON t.id=te.torneo_id WHERE te.equipo_id=? FOR UPDATE";
                boolean historial = false;
                try (PreparedStatement ps = conn.prepareStatement(vinculados)) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            if ("ACTIVO".equals(rs.getString("estado"))) {
                                throw new IllegalArgumentException("No se puede eliminar un equipo que participa en un torneo activo.");
                            }
                            historial = true;
                        }
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM torneos WHERE campeon_id=? FOR UPDATE")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) { if (rs.next()) { historial = true; } }
                }
                if (historial) {
                    throw new IllegalArgumentException("El equipo pertenece al historial de un torneo. Elimina primero ese torneo finalizado o cancelado.");
                }
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM equipos WHERE id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public void registrar(Equipo equipo) throws SQLException {
        String sql = "INSERT INTO equipos (nombre, escudo_url, telefono, usuario_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, equipo.getNombre());
            ps.setString(2, equipo.getEscudoUrl());
            ps.setString(3, equipo.getTelefono());
            ps.setInt(4, equipo.getUsuarioId());
            ps.executeUpdate();
        }
    }

    public void cambiarEstado(int id, String estado) throws SQLException {
        if (!"APROBADO".equals(estado) && !"RECHAZADO".equals(estado)) {
            throw new IllegalArgumentException("Estado de equipo inválido.");
        }
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                bloquearPreparacion(conn);
                String sql = "SELECT e.id, EXISTS(SELECT 1 FROM torneo_equipos te JOIN torneos t ON t.id=te.torneo_id"
                        + " WHERE te.equipo_id=e.id AND t.estado='ACTIVO') AS participa FROM equipos e WHERE e.id=? FOR UPDATE";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { throw new IllegalArgumentException("El equipo no existe."); }
                        if (rs.getBoolean("participa")) {
                            throw new IllegalArgumentException("El equipo participa en un torneo activo y su aprobación está bloqueada.");
                        }
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement("UPDATE equipos SET estado=? WHERE id=?")) {
                    ps.setString(1, estado);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public static void bloquearPreparacion(Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM control_torneo WHERE id=1 FOR UPDATE");
             ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) { throw new SQLException("Falta inicializar el control del torneo."); }
        }
    }

    public static Equipo leer(ResultSet rs) throws SQLException {
        return new Equipo(rs.getInt("id"), rs.getString("nombre"), rs.getString("escudo_url"),
                rs.getString("telefono"), rs.getInt("usuario_id"), rs.getString("dueno"), rs.getString("estado"));
    }

    private Equipo leerGestion(ResultSet rs) throws SQLException {
        Equipo equipo = leer(rs);
        equipo.setEstadoBloqueado(rs.getBoolean("bloqueado"));
        return equipo;
    }
}
