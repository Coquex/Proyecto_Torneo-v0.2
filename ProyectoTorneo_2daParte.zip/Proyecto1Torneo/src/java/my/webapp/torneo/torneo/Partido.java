package my.webapp.torneo.torneo;

public class Partido {
    private final int id;
    private final int ronda;
    private final int numero;
    private final String local;
    private final String visitante;
    private final Integer golesLocal;
    private final Integer golesVisitante;
    private final String estado;
    private final Integer siguientePartidoId;
    private final Integer puestoSiguiente;

    public Partido(int id, int ronda, int numero, String local, String visitante, Integer golesLocal,
                   Integer golesVisitante, String estado, Integer siguientePartidoId, Integer puestoSiguiente) {
        this.id = id;
        this.ronda = ronda;
        this.numero = numero;
        this.local = local;
        this.visitante = visitante;
        this.golesLocal = golesLocal;
        this.golesVisitante = golesVisitante;
        this.estado = estado;
        this.siguientePartidoId = siguientePartidoId;
        this.puestoSiguiente = puestoSiguiente;
    }

    public int getId() { return id; }
    public int getRonda() { return ronda; }
    public int getNumero() { return numero; }
    public String getLocal() { return local; }
    public String getVisitante() { return visitante; }
    public Integer getGolesLocal() { return golesLocal; }
    public Integer getGolesVisitante() { return golesVisitante; }
    public String getEstado() { return estado; }
    public Integer getSiguientePartidoId() { return siguientePartidoId; }
    public Integer getPuestoSiguiente() { return puestoSiguiente; }
}
