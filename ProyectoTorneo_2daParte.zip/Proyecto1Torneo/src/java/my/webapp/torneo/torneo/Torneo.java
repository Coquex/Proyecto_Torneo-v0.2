package my.webapp.torneo.torneo;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Torneo {
    private final int id;
    private final String nombre;
    private final String imagenUrl;
    private final LocalDate fechaInicio;
    private final LocalDate fechaFin;
    private final BigDecimal premio;
    private final String estado;

    public Torneo(int id, String nombre, String imagenUrl, LocalDate fechaInicio, LocalDate fechaFin, BigDecimal premio, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.imagenUrl = imagenUrl;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.premio = premio;
        this.estado = estado;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getImagenUrl() { return imagenUrl; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public LocalDate getFechaFin() { return fechaFin; }
    public BigDecimal getPremio() { return premio; }
    public String getEstado() { return estado; }
}
