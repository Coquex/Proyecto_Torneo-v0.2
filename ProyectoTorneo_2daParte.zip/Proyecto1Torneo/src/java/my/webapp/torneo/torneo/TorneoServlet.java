package my.webapp.torneo.torneo;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.Set;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import my.webapp.torneo.util.Web;
import my.webapp.torneo.equipo.Equipo;

public class TorneoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = Web.dato(request, "action");
        TorneoDao dao = new TorneoDao();
        try {
            if ("nuevo".equals(action)) {
                if (!Web.admin(request, response)) { return; }
                formulario(request, response);
            } else if ("editar".equals(action) || "confirmar".equals(action)) {
                if (!Web.admin(request, response)) { return; }
                mostrarGestion(request, response, Web.id(Web.dato(request, "id")), "confirmar".equals(action));
            } else if ("cancelacion".equals(action)) {
                if (!Web.admin(request, response)) { return; }
                mostrarCancelacion(request, response, Web.id(Web.dato(request, "id")));
            } else if ("ver".equals(action)) {
                Torneo torneo = dao.buscar(Web.id(Web.dato(request, "id")));
                if (torneo == null) { response.sendError(404); return; }
                request.setAttribute("torneo", torneo);
                request.setAttribute("participantes", dao.participantes(torneo.getId()));
                request.setAttribute("partidos", dao.partidos(torneo.getId()));
                request.getRequestDispatcher("/WEB-INF/views/torneo-ver.jsp").forward(request, response);
            } else if (action.isEmpty() || "listar".equals(action)) {
                request.setAttribute("torneos", dao.listar());
                request.getRequestDispatcher("/WEB-INF/views/torneos.jsp").forward(request, response);
            } else { response.sendError(404); }
        } catch (IllegalArgumentException e) { response.sendError(400); }
        catch (SQLException e) { Web.errorBD(response, e); }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.admin(request, response)) { return; }
        if (!Web.tokenValido(request)) { response.sendError(403); return; }
        String action = Web.dato(request, "action");
        if (!"crear".equals(action) && !"actualizar".equals(action) && !"eliminar".equals(action) && !"cancelar".equals(action)) {
            response.sendError(404); return;
        }
        int id = 0;
        if (!"crear".equals(action)) {
            try { id = Web.id(Web.dato(request, "id")); }
            catch (IllegalArgumentException e) { response.sendError(400); return; }
        }
        try {
            TorneoDao dao = new TorneoDao();
            if ("actualizar".equals(action)) {
                Torneo actual = dao.buscar(id);
                if (actual == null) { response.sendError(404); return; }
                Torneo cambios = leerFormulario(request, id, actual.getEstado());
                if (!dao.actualizar(cambios)) { response.sendError(404); return; }
                Web.redirigir(request, response, "/TorneoServlet?action=ver&id=" + id + "&estado=actualizado");
            } else if ("eliminar".equals(action)) {
                if (!"si".equals(request.getParameter("confirmacion"))) { response.sendError(400); return; }
                if (!dao.eliminar(id)) { response.sendError(404); return; }
                Web.redirigir(request, response, "/TorneoServlet?estado=eliminado");
            } else if ("cancelar".equals(action)) {
                if (!"si".equals(request.getParameter("confirmacion"))) { response.sendError(400); return; }
                if (!dao.cancelar(id)) { response.sendError(404); return; }
                Web.redirigir(request, response, "/TorneoServlet?action=ver&id=" + id + "&estado=cancelado");
            } else {
                if (dao.buscarActivo() != null) {
                    error(request, response, action, id, "Ya existe un torneo activo.");
                    return;
                }
                Torneo torneo = leerFormulario(request, 0, "ACTIVO");
                String[] valores = request.getParameterValues("equipos");
                Set<Integer> seleccionados = new HashSet<>();
                if (valores != null) {
                    for (String valor : valores) { seleccionados.add(Web.id(valor)); }
                }
                if (valores == null || valores.length != 16 || seleccionados.size() != 16) {
                    throw new IllegalArgumentException("Selecciona exactamente 16 equipos distintos.");
                }
                int nuevoId = dao.crear(torneo, seleccionados);
                Web.redirigir(request, response, "/TorneoServlet?action=ver&id=" + nuevoId + "&estado=creado");
            }
        } catch (DateTimeParseException e) {
            error(request, response, action, id, "Las fechas del torneo no son válidas.");
        } catch (IllegalArgumentException e) {
            error(request, response, action, id, e.getMessage());
        } catch (SQLException e) {
            if ("crear".equals(action) && e.getErrorCode() == 1062) {
                error(request, response, action, id, "Ya existe un torneo activo. Actualiza la página.");
            }
            else { Web.errorBD(response, e); }
        }
    }

    private Torneo leerFormulario(HttpServletRequest request, int id, String estado) {
        String nombre = Web.dato(request, "nombre");
        String imagen = Web.dato(request, "imagen_url");
        String inicio = Web.dato(request, "fecha_inicio");
        String fin = Web.dato(request, "fecha_fin");
        String premio = Web.dato(request, "premio");
        if (nombre.isEmpty() || nombre.length() > 120) {
            throw new IllegalArgumentException("El nombre del torneo es obligatorio y admite hasta 120 caracteres.");
        }
        if (!Web.imagenValida(imagen)) { throw new IllegalArgumentException("Ingresa una URL de imagen http o https válida."); }
        if (!inicio.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}") || !fin.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            throw new IllegalArgumentException("Completa las dos fechas del torneo.");
        }
        LocalDate fechaInicio = LocalDate.parse(inicio);
        LocalDate fechaFin = LocalDate.parse(fin);
        if (fechaInicio.getYear() < 1000 || fechaFin.getYear() < 1000 || fechaFin.isBefore(fechaInicio)) {
            throw new IllegalArgumentException("La fecha final debe ser igual o posterior a la fecha inicial.");
        }
        if (!premio.matches("[0-9]{1,10}(\\.[0-9]{1,2})?")) {
            throw new IllegalArgumentException("El premio debe ser un monto no negativo con hasta dos decimales.");
        }
        return new Torneo(id, nombre, imagen, fechaInicio, fechaFin, new BigDecimal(premio), estado);
    }

    private void formulario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            TorneoDao dao = new TorneoDao();
            Torneo activo = dao.buscarActivo();
            Set<Integer> equiposOcupados = new HashSet<>();
            if (activo != null) {
                for (Equipo equipo : dao.participantes(activo.getId())) {
                    equiposOcupados.add(equipo.getId());
                }
            }
            request.setAttribute("aprobados", dao.aprobados());
            request.setAttribute("hayActivo", activo != null);
            request.setAttribute("equiposOcupados", equiposOcupados);
            request.getRequestDispatcher("/WEB-INF/views/torneo-form.jsp").forward(request, response);
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void mostrarGestion(HttpServletRequest request, HttpServletResponse response, int id, boolean eliminacion) throws ServletException, IOException {
        try {
            TorneoDao dao = new TorneoDao();
            Torneo torneo = dao.buscar(id);
            if (torneo == null) { response.sendError(404); return; }
            request.setAttribute("torneo", torneo);
            request.setAttribute("puedeEliminar", dao.puedeEliminar(id));
            request.getRequestDispatcher(eliminacion ? "/WEB-INF/views/torneo-eliminar.jsp" : "/WEB-INF/views/torneo-editar.jsp").forward(request, response);
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void mostrarCancelacion(HttpServletRequest request, HttpServletResponse response, int id) throws ServletException, IOException {
        try {
            Torneo torneo = new TorneoDao().buscar(id);
            if (torneo == null) { response.sendError(404); return; }
            request.setAttribute("torneo", torneo);
            request.getRequestDispatcher("/WEB-INF/views/torneo-cancelar.jsp").forward(request, response);
        } catch (SQLException e) { Web.errorBD(response, e); }
    }

    private void error(HttpServletRequest request, HttpServletResponse response, String action, int id, String mensaje) throws ServletException, IOException {
        request.setAttribute("error", mensaje);
        response.setStatus(422);
        if ("crear".equals(action)) { formulario(request, response); }
        else if ("cancelar".equals(action)) { mostrarCancelacion(request, response, id); }
        else { mostrarGestion(request, response, id, "eliminar".equals(action)); }
    }
}
