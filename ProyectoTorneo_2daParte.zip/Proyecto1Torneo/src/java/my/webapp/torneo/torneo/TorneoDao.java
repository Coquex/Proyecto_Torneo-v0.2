package my.webapp.torneo.torneo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import my.webapp.torneo.database.Database;
import my.webapp.torneo.equipo.Equipo;
import my.webapp.torneo.equipo.EquipoDao;

public class TorneoDao {

    public List<Torneo> listar() throws SQLException {
        List<Torneo> torneos = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM torneos ORDER BY id DESC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) { torneos.add(leer(rs)); }
        }
        return torneos;
    }

    public Torneo buscar(int id) throws SQLException {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM torneos WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? leer(rs) : null; }
        }
    }

    public Torneo buscarActivo() throws SQLException {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM torneos WHERE estado='ACTIVO'");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? leer(rs) : null;
        }
    }

    public List<Equipo> aprobados() throws SQLException {
        List<Equipo> equipos = new ArrayList<>();
        String sql = "SELECT e.*, u.Name AS dueno FROM equipos e JOIN Users u ON u.Id=e.usuario_id WHERE e.estado='APROBADO' ORDER BY e.nombre";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) { equipos.add(EquipoDao.leer(rs)); }
        }
        return equipos;
    }

    public List<Equipo> participantes(int torneoId) throws SQLException {
        List<Equipo> equipos = new ArrayList<>();
        String sql = "SELECT e.*, u.Name AS dueno FROM torneo_equipos te JOIN equipos e ON e.id=te.equipo_id"
                + " JOIN Users u ON u.Id=e.usuario_id WHERE te.torneo_id=? ORDER BY e.nombre";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, torneoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) { equipos.add(EquipoDao.leer(rs)); }
            }
        }
        return equipos;
    }

    public List<Partido> partidos(int torneoId) throws SQLException {
        List<Partido> partidos = new ArrayList<>();
        String sql = "SELECT p.*, r.numero AS ronda_numero, l.nombre AS local_nombre, v.nombre AS visitante_nombre"
                + " FROM partidos p JOIN rondas r ON r.id=p.ronda_id LEFT JOIN equipos l ON l.id=p.local_id"
                + " LEFT JOIN equipos v ON v.id=p.visitante_id WHERE p.torneo_id=? ORDER BY r.numero, p.numero";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, torneoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    partidos.add(new Partido(rs.getInt("id"), rs.getInt("ronda_numero"), rs.getInt("numero"),
                            rs.getString("local_nombre"), rs.getString("visitante_nombre"),
                            (Integer) rs.getObject("goles_local"), (Integer) rs.getObject("goles_visitante"),
                            rs.getString("estado"), (Integer) rs.getObject("siguiente_partido_id"),
                            rs.getObject("puesto_siguiente") == null ? null : rs.getInt("puesto_siguiente")));
                }
            }
        }
        return partidos;
    }

    public int crear(Torneo torneo, Set<Integer> seleccionados) throws SQLException {
        if (seleccionados.size() != 16) { throw new IllegalArgumentException("Debes seleccionar exactamente 16 equipos distintos."); }
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                EquipoDao.bloquearPreparacion(conn);
                try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM torneos WHERE estado='ACTIVO'");
                     ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) { throw new IllegalArgumentException("Ya existe un torneo activo."); }
                }
                List<Integer> aprobados = new ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM equipos WHERE estado='APROBADO' ORDER BY id FOR UPDATE");
                     ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) { aprobados.add(rs.getInt("id")); }
                }
                if (aprobados.size() != 16) {
                    throw new IllegalArgumentException("Deben existir exactamente 16 equipos aprobados antes de crear el torneo.");
                }
                if (!new HashSet<>(aprobados).equals(seleccionados)) {
                    throw new IllegalArgumentException("Selecciona los 16 equipos aprobados.");
                }
                int torneoId;
                String sql = "INSERT INTO torneos (nombre, imagen_url, fecha_inicio, fecha_fin, premio) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, torneo.getNombre());
                    ps.setString(2, torneo.getImagenUrl());
                    ps.setDate(3, Date.valueOf(torneo.getFechaInicio()));
                    ps.setDate(4, Date.valueOf(torneo.getFechaFin()));
                    ps.setBigDecimal(5, torneo.getPremio());
                    ps.executeUpdate();
                    torneoId = claveGenerada(ps);
                }
                try (PreparedStatement ps = conn.prepareStatement("INSERT INTO torneo_equipos (torneo_id, equipo_id) VALUES (?, ?)")) {
                    for (int equipoId : aprobados) {
                        ps.setInt(1, torneoId);
                        ps.setInt(2, equipoId);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                Collections.shuffle(aprobados, new SecureRandom());
                generarLlaves(conn, torneoId, aprobados);
                conn.commit();
                return torneoId;
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public boolean actualizar(Torneo torneo) throws SQLException {
        String sql = "UPDATE torneos SET nombre=?, imagen_url=?, fecha_inicio=?, fecha_fin=?, premio=? WHERE id=?";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, torneo.getNombre());
            ps.setString(2, torneo.getImagenUrl());
            ps.setDate(3, Date.valueOf(torneo.getFechaInicio()));
            ps.setDate(4, Date.valueOf(torneo.getFechaFin()));
            ps.setBigDecimal(5, torneo.getPremio());
            ps.setInt(6, torneo.getId());
            if (ps.executeUpdate() > 0) { return true; }
            // Guardar los mismos valores también es válido si el registro existe.
            try (PreparedStatement existe = conn.prepareStatement("SELECT id FROM torneos WHERE id=?")) {
                existe.setInt(1, torneo.getId());
                try (ResultSet rs = existe.executeQuery()) { return rs.next(); }
            }
        }
    }

    public boolean puedeEliminar(int id) throws SQLException {
        String sql = "SELECT estado IN ('FINALIZADO','CANCELADO') AS permitido FROM torneos WHERE id=?";
        try (Connection conn = Database.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() && rs.getBoolean("permitido"); }
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                EquipoDao.bloquearPreparacion(conn);
                try (PreparedStatement ps = conn.prepareStatement("SELECT estado, campeon_id FROM torneos WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        if (!"FINALIZADO".equals(rs.getString("estado")) && !"CANCELADO".equals(rs.getString("estado"))) {
                            throw new IllegalArgumentException("No se puede eliminar un torneo activo. Debe finalizarse o cancelarse primero.");
                        }
                    }
                }
                // Primero se quitan los enlaces entre partidos para respetar sus llaves foráneas.
                String[] operaciones = {
                    "UPDATE partidos SET siguiente_partido_id=NULL, puesto_siguiente=NULL WHERE torneo_id=?",
                    "DELETE FROM partidos WHERE torneo_id=?",
                    "DELETE FROM rondas WHERE torneo_id=?",
                    "DELETE FROM torneo_equipos WHERE torneo_id=?",
                    "DELETE FROM torneos WHERE id=?"
                };
                for (String sql : operaciones) {
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setInt(1, id);
                        ps.executeUpdate();
                    }
                }
                conn.commit();
                return true;
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public boolean cancelar(int id) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                EquipoDao.bloquearPreparacion(conn);
                try (PreparedStatement ps = conn.prepareStatement("SELECT estado FROM torneos WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        if (!"ACTIVO".equals(rs.getString("estado"))) {
                            throw new IllegalArgumentException("Solo se puede cancelar un torneo activo.");
                        }
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement("UPDATE torneos SET estado='CANCELADO' WHERE id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException | IllegalArgumentException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    private void generarLlaves(Connection conn, int torneoId, List<Integer> equipos) throws SQLException {
        String[] nombres = {"Ronda preliminar", "Cuartos de final", "Semifinal", "Final"};
        int[] rondas = new int[4];
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO rondas (torneo_id, numero, nombre) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            for (int r = 0; r < 4; r++) {
                ps.setInt(1, torneoId);
                ps.setInt(2, r + 1);
                ps.setString(3, nombres[r]);
                ps.executeUpdate();
                rondas[r] = claveGenerada(ps);
            }
        }
        int[][] ids = new int[4][];
        String sql = "INSERT INTO partidos (torneo_id, ronda_id, numero, local_id, visitante_id, siguiente_partido_id, puesto_siguiente)"
                + " VALUES (?, ?, ?, ?, ?, ?, ?)";
        // Se guarda primero la final para poder enlazar cada partido con uno que ya existe.
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            for (int r = 3; r >= 0; r--) {
                int cantidad = 8 >> r;
                ids[r] = new int[cantidad];
                for (int i = 0; i < cantidad; i++) {
                    ps.setInt(1, torneoId);
                    ps.setInt(2, rondas[r]);
                    ps.setInt(3, i + 1);
                    ps.setNull(4, Types.INTEGER);
                    ps.setNull(5, Types.INTEGER);
                    if (r == 0) {
                        ps.setInt(4, equipos.get(i * 2));
                        ps.setInt(5, equipos.get(i * 2 + 1));
                    }
                    ps.setNull(6, Types.INTEGER);
                    ps.setNull(7, Types.TINYINT);
                    if (r < 3) {
                        ps.setInt(6, ids[r + 1][i / 2]);
                        ps.setInt(7, i % 2 + 1);
                    }
                    ps.executeUpdate();
                    ids[r][i] = claveGenerada(ps);
                }
            }
        }
    }

    private int claveGenerada(PreparedStatement ps) throws SQLException {
        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (!rs.next()) { throw new SQLException("No se generó el identificador."); }
            return rs.getInt(1);
        }
    }

    private Torneo leer(ResultSet rs) throws SQLException {
        return new Torneo(rs.getInt("id"), rs.getString("nombre"), rs.getString("imagen_url"),
                rs.getDate("fecha_inicio").toLocalDate(), rs.getDate("fecha_fin").toLocalDate(),
                rs.getBigDecimal("premio"), rs.getString("estado"));
    }
}
