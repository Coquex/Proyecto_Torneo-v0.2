<%@page pageEncoding="UTF-8"%>
<% request.setAttribute("titulo", "Crear cuenta"); %>
<%@include file="WEB-INF/views/header.jspf"%>
<section class="panel acceso mx-auto">
    <p class="etiqueta">Registro de usuarios</p>
    <h1 class="h2">Crear cuenta</h1>
    <p class="text-secondary">Completa tus datos para participar.</p>
    <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <form method="post" action="<%= contexto %>/RegisterServlet">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="mb-3">
            <label for="name" class="form-label">Nombre completo</label>
            <input class="form-control" id="name" name="txtname" maxlength="120" autocomplete="name" value="<%= Web.texto(Web.dato(request, "txtname")) %>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <input class="form-control" id="email" name="txtemail" type="email" maxlength="254" autocomplete="email" value="<%= Web.texto(Web.dato(request, "txtemail")) %>" required>
        </div>
        <div class="mb-4">
            <label for="password" class="form-label">Contraseña</label>
            <input class="form-control" id="password" name="txtpwd" type="password" minlength="10" maxlength="128" autocomplete="new-password" required aria-describedby="ayuda-password">
            <div class="form-text" id="ayuda-password">Utiliza entre 10 y 128 caracteres.</div>
        </div>
        <button class="btn btn-primary w-100">Registrarse</button>
    </form>
    <p class="mt-4 mb-0"><a href="<%= contexto %>/login.jsp">Ya tengo una cuenta</a></p>
</section>
<%@include file="WEB-INF/views/footer.jspf"%>
