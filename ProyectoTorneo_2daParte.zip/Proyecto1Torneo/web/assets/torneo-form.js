const formulario = document.getElementById('form-torneo');
const inicio = document.getElementById('inicio');
const fin = document.getElementById('fin');
const cajas = [...formulario.querySelectorAll('input[name="equipos"]')];
const conteo = document.getElementById('conteo');
const botonCrear = document.getElementById('crear-torneo');
const controlCrear = document.getElementById('control-crear-torneo');
const avisoActivo = document.getElementById('aviso-torneo-activo');
const estadoCreacion = document.getElementById('estado-creacion');
const hayTorneoActivo = formulario.dataset.torneoActivo === 'true';

function actualizar() {
    const cantidad = cajas.filter(caja => caja.checked).length;
    conteo.textContent = hayTorneoActivo ? 'Selección bloqueada: ya hay un torneo activo.' : cantidad + ' de 16 equipos seleccionados';
    if (cajas.length) { cajas[0].setCustomValidity(hayTorneoActivo || cantidad === 16 ? '' : 'Selecciona exactamente 16 equipos.'); }
    fin.setCustomValidity(inicio.value && fin.value && fin.value < inicio.value ? 'La fecha final debe ser igual o posterior a la inicial.' : '');
}
function mostrarAviso() {
    avisoActivo.hidden = false;
    botonCrear.setAttribute('aria-describedby', avisoActivo.id);
    estadoCreacion.textContent = 'No se puede crear el torneo. Ya existe un torneo activo. Solo se permite uno a la vez.';
}
function ocultarAviso() {
    avisoActivo.hidden = true;
    botonCrear.removeAttribute('aria-describedby');
    estadoCreacion.textContent = '';
}

formulario.addEventListener('change', actualizar);
formulario.addEventListener('input', () => {
    actualizar();
    ocultarAviso();
});
formulario.addEventListener('submit', evento => {
    actualizar();
    if (!formulario.reportValidity()) {
        evento.preventDefault();
        return;
    }
    if (hayTorneoActivo) {
        evento.preventDefault();
        mostrarAviso();
    }
});
document.addEventListener('keydown', evento => {
    if (evento.key === 'Escape') { ocultarAviso(); }
});
document.addEventListener('pointerdown', evento => {
    if (!controlCrear.contains(evento.target)) { ocultarAviso(); }
});
controlCrear.addEventListener('focusout', evento => {
    if (!controlCrear.contains(evento.relatedTarget)) { ocultarAviso(); }
});
actualizar();
if (!avisoActivo.hidden) {
    mostrarAviso();
    botonCrear.focus();
}
