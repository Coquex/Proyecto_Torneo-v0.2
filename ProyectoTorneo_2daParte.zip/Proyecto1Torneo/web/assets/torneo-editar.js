const fechaInicio = document.getElementById('inicio');
const fechaFin = document.getElementById('fin');
function validarFechas() {
    fechaFin.setCustomValidity(fechaInicio.value && fechaFin.value && fechaFin.value < fechaInicio.value
        ? 'La fecha final debe ser igual o posterior a la inicial.' : '');
}
fechaInicio.addEventListener('input', validarFechas);
fechaFin.addEventListener('input', validarFechas);
validarFechas();
