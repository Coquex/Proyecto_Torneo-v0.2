const dialogoConfirmacion = document.getElementById('confirmacion-accion');
if (dialogoConfirmacion && typeof dialogoConfirmacion.showModal === 'function') {
    const formConfirmacion = document.getElementById('form-confirmacion');
    let enlaceOrigen;
    document.querySelectorAll('[data-confirmar]').forEach(enlace => {
        enlace.addEventListener('click', evento => {
            evento.preventDefault();
            enlaceOrigen = enlace;
            document.getElementById('titulo-confirmacion').textContent = enlace.dataset.titulo;
            document.getElementById('mensaje-confirmacion').textContent = enlace.dataset.mensaje;
            document.getElementById('advertencia-confirmacion').hidden = enlace.dataset.accion !== 'eliminar';
            dialogoConfirmacion.setAttribute('aria-describedby', enlace.dataset.accion === 'eliminar'
                ? 'mensaje-confirmacion advertencia-confirmacion' : 'mensaje-confirmacion');
            document.getElementById('accion-confirmacion').value = enlace.dataset.accion;
            document.getElementById('id-confirmacion').value = enlace.dataset.id;
            formConfirmacion.action = enlace.dataset.destino;
            const boton = document.getElementById('boton-confirmacion');
            boton.textContent = enlace.dataset.boton;
            boton.disabled = false;
            dialogoConfirmacion.showModal();
        });
    });
    document.getElementById('cerrar-confirmacion').addEventListener('click', () => dialogoConfirmacion.close());
    dialogoConfirmacion.addEventListener('close', () => enlaceOrigen?.focus());
    dialogoConfirmacion.addEventListener('click', evento => {
        const rect = dialogoConfirmacion.getBoundingClientRect();
        if (evento.target === dialogoConfirmacion && (evento.clientX < rect.left || evento.clientX > rect.right
                || evento.clientY < rect.top || evento.clientY > rect.bottom)) { dialogoConfirmacion.close(); }
    });
    formConfirmacion.addEventListener('submit', () => { document.getElementById('boton-confirmacion').disabled = true; });
}
