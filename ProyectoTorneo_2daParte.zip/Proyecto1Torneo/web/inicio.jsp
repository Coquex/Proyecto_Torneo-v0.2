<%@page pageEncoding="UTF-8"%>
<% request.setAttribute("titulo", "Inicio"); %>
<%@include file="WEB-INF/views/header.jspf"%>
<section class="bienvenida mb-4">
    <p class="etiqueta">Gestión de la competición</p>
    <h1>Bienvenido, <%= Web.texto(usuarioActual.getName()) %></h1>
    <p class="text-secondary mb-0">Registra equipos y consulta los enfrentamientos del torneo.</p>
</section>
<div class="row g-4">
    <div class="col-md-6">
        <section class="panel h-100">
            <h2 class="h4">Equipos</h2>
            <p>Consulta los equipos aprobados y registra tu equipo con su escudo y teléfono.</p>
            <div class="d-flex flex-wrap gap-2">
                <a class="btn btn-primary" href="<%= contexto %>/EquipoServlet?action=nuevo">Registrar equipo</a>
                <a class="btn btn-outline-primary" href="<%= contexto %>/EquipoServlet">Ver equipos</a>
            </div>
        </section>
    </div>
    <div class="col-md-6">
        <section class="panel h-100">
            <h2 class="h4">Torneos</h2>
            <p>Consulta los participantes y las llaves de las cuatro rondas eliminatorias.</p>
            <div class="d-flex flex-wrap gap-2">
                <a class="btn btn-primary" href="<%= contexto %>/TorneoServlet">Ver torneos</a>
                <% if (usuarioActual.isAdmin()) { %>
                <a class="btn btn-outline-primary" href="<%= contexto %>/TorneoServlet?action=nuevo">Crear torneo</a>
                <% } %>
            </div>
        </section>
    </div>
</div>
<%@include file="WEB-INF/views/footer.jspf"%>
