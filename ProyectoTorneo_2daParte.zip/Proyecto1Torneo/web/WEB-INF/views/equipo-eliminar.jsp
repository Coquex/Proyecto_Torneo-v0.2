<%@page pageEncoding="UTF-8"%>
<%@page import="my.webapp.torneo.equipo.Equipo"%>
<% request.setAttribute("titulo", "Eliminar equipo"); %>
<%@include file="header.jspf"%>
<% Equipo equipo = (Equipo) request.getAttribute("equipo"); %>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Confirmación</p><h1 class="h3">Eliminar equipo</h1>
    <h2 class="h5 my-3"><%= Web.texto(equipo.getNombre()) %></h2>
    <% if (request.getAttribute("error") != null) { %><div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div><% } %>
    <% if (Boolean.TRUE.equals(request.getAttribute("puedeEliminar"))) { %>
    <p>El equipo se eliminará definitivamente. Esta acción no se puede deshacer.</p>
    <form method="post" action="<%= contexto %>/EquipoServlet" class="d-flex flex-wrap gap-2">
        <input type="hidden" name="action" value="eliminar"><input type="hidden" name="id" value="<%= equipo.getId() %>">
        <input type="hidden" name="confirmacion" value="si"><input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <button class="btn btn-outline-danger">Confirmar eliminación</button>
        <a class="btn btn-outline-secondary" href="<%= contexto %>/EquipoServlet?action=editar&amp;id=<%= equipo.getId() %>">Volver</a>
    </form>
    <% } else { %>
    <div class="alert alert-warning">El equipo está asociado a un torneo. Su registro se conserva hasta eliminar ese torneo finalizado o cancelado.</div>
    <a class="btn btn-outline-secondary" href="<%= contexto %>/EquipoServlet?action=editar&amp;id=<%= equipo.getId() %>">Volver</a>
    <% } %>
</section>
<%@include file="footer.jspf"%>
