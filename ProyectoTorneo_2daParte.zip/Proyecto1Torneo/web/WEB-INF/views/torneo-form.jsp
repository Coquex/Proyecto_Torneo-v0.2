<%@page pageEncoding="UTF-8"%>
<%@page import="java.util.List,java.util.Set,java.util.Arrays,my.webapp.torneo.equipo.Equipo"%>
<% request.setAttribute("titulo", "Crear torneo"); %>
<%@include file="header.jspf"%>
<%
    List<Equipo> aprobados = (List<Equipo>) request.getAttribute("aprobados");
    Set<Integer> equiposOcupados = (Set<Integer>) request.getAttribute("equiposOcupados");
    boolean hayActivo = Boolean.TRUE.equals(request.getAttribute("hayActivo"));
    boolean puedeIntentar = hayActivo || aprobados.size() == 16;
    String mensajeError = (String) request.getAttribute("error");
    boolean bloqueoActivo = hayActivo && mensajeError != null && mensajeError.startsWith("Ya existe un torneo activo.");
    String[] seleccion = request.getParameterValues("equipos");
    List<String> marcados = seleccion == null ? java.util.Collections.emptyList() : Arrays.asList(seleccion);
%>
<section class="panel">
    <p class="etiqueta">Administración</p>
    <h1 class="h2">Crear torneo</h1>
    <% if (hayActivo) { %>
        <p class="text-secondary">La selección de equipos está bloqueada mientras haya un torneo activo.</p>
    <% } else { %>
        <p class="text-secondary">Selecciona los 16 equipos aprobados. Al crear el torneo se sortearán las llaves y quedarán guardadas.</p>
    <% } %>
    <% if (mensajeError != null && !bloqueoActivo) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <% if (!hayActivo && aprobados.size() != 16) { %>
        <div class="alert alert-warning">Se requieren exactamente 16 equipos aprobados. Actualmente hay <%= aprobados.size() %>.</div>
    <% } %>
    <form method="post" action="<%= contexto %>/TorneoServlet" id="form-torneo" data-torneo-activo="<%= hayActivo %>">
        <input type="hidden" name="action" value="crear">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label" for="nombre">Nombre del torneo</label>
                <input class="form-control" id="nombre" name="nombre" maxlength="120" value="<%= Web.texto(Web.dato(request, "nombre")) %>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="imagen">URL de la imagen</label>
                <input class="form-control" id="imagen" name="imagen_url" maxlength="1000" pattern="https?://.+|assets/imagenes/(escudo|torneo)\.svg" value="<%= Web.texto("POST".equals(request.getMethod()) ? Web.dato(request, "imagen_url") : "assets/imagenes/torneo.svg") %>" required>
                <div class="form-text">URL http/https o la imagen de ejemplo incluida.</div>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="inicio">Fecha de inicio</label>
                <input class="form-control" id="inicio" name="fecha_inicio" type="date" min="1000-01-01" max="9999-12-31" value="<%= Web.texto(Web.dato(request, "fecha_inicio")) %>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="fin">Fecha de finalización</label>
                <input class="form-control" id="fin" name="fecha_fin" type="date" min="1000-01-01" max="9999-12-31" value="<%= Web.texto(Web.dato(request, "fecha_fin")) %>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="premio">Premio en colones (₡)</label>
                <input class="form-control" id="premio" name="premio" type="number" min="0" max="9999999999.99" step="0.01" value="<%= Web.texto(Web.dato(request, "premio")) %>" required>
            </div>
        </div>
        <fieldset class="mb-4">
            <legend class="h5">Equipos aprobados</legend>
            <p class="small text-secondary">Una vez creado el torneo, sus participantes y el sorteo quedan fijos.</p>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-2">
            <% for (Equipo equipo : aprobados) { boolean enActivo = equiposOcupados.contains(equipo.getId()); %>
                <div class="col">
                    <label class="seleccion-equipo d-flex gap-2 align-items-center <%= hayActivo ? "equipo-bloqueado" : "" %>">
                        <input class="form-check-input flex-shrink-0 mt-0" type="checkbox" name="equipos" value="<%= equipo.getId() %>" <%= !hayActivo && marcados.contains(Integer.toString(equipo.getId())) ? "checked" : "" %> <%= hayActivo ? "disabled aria-describedby=\"estado-equipo-" + equipo.getId() + "\"" : "" %>>
                        <span class="equipo-opcion">
                            <span><%= Web.texto(equipo.getNombre()) %></span>
                            <% if (hayActivo) { %>
                                <small class="equipo-estado" id="estado-equipo-<%= equipo.getId() %>"><%= enActivo ? "Participando en el torneo activo" : "Selección bloqueada por torneo activo" %></small>
                            <% } %>
                        </span>
                    </label>
                </div>
            <% } %>
            </div>
            <p class="small mt-3 mb-0" id="conteo" aria-live="polite"></p>
        </fieldset>
        <div class="d-flex flex-wrap align-items-start gap-2">
            <div class="crear-torneo-control" id="control-crear-torneo">
                <button class="btn btn-primary" type="submit" id="crear-torneo" <%= bloqueoActivo ? "aria-describedby=\"aviso-torneo-activo\"" : "" %> <%= puedeIntentar ? "" : "disabled" %>>Crear torneo y sortear llaves</button>
                <div class="aviso-torneo-activo" id="aviso-torneo-activo" role="tooltip" <%= bloqueoActivo ? "" : "hidden" %>>
                    <span class="aviso-torneo-icono" aria-hidden="true">!</span>
                    <div>
                        <strong>No se puede crear el torneo</strong>
                        <p>Ya existe un torneo activo. Solo se permite uno a la vez.</p>
                    </div>
                </div>
            </div>
            <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet">Cancelar</a>
        </div>
        <p class="visually-hidden" id="estado-creacion" role="status" aria-live="polite"></p>
    </form>
</section>
<script src="<%= contexto %>/assets/torneo-form.js?v=0.2-equipos-bloqueados"></script>
<%@include file="footer.jspf"%>
