<%@page pageEncoding="UTF-8"%>
<%@page import="my.webapp.torneo.torneo.Torneo"%>
<% request.setAttribute("titulo", "Editar torneo"); %>
<%@include file="header.jspf"%>
<%
    Torneo torneo = (Torneo) request.getAttribute("torneo");
    boolean enviado = "POST".equals(request.getMethod());
    String nombre = enviado ? Web.dato(request, "nombre") : torneo.getNombre();
    String imagen = enviado ? Web.dato(request, "imagen_url") : torneo.getImagenUrl();
    String inicio = enviado ? Web.dato(request, "fecha_inicio") : torneo.getFechaInicio().toString();
    String fin = enviado ? Web.dato(request, "fecha_fin") : torneo.getFechaFin().toString();
    String premio = enviado ? Web.dato(request, "premio") : torneo.getPremio().toPlainString();
    boolean activo = "ACTIVO".equals(torneo.getEstado());
    boolean puedeEliminar = Boolean.TRUE.equals(request.getAttribute("puedeEliminar"));
%>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Administración</p>
    <h1 class="h2">Editar torneo</h1>
    <p class="text-secondary">Actualiza sus datos generales. Los participantes, las llaves y los resultados se conservan.</p>
    <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <form method="post" action="<%= contexto %>/TorneoServlet">
        <input type="hidden" name="action" value="actualizar">
        <input type="hidden" name="id" value="<%= torneo.getId() %>">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="mb-3">
            <label class="form-label" for="nombre">Nombre del torneo</label>
            <input class="form-control" id="nombre" name="nombre" maxlength="120" value="<%= Web.texto(nombre) %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="imagen">URL de la imagen</label>
            <input class="form-control" id="imagen" name="imagen_url" maxlength="1000" pattern="https?://.+|assets/imagenes/(escudo|torneo)\.svg" value="<%= Web.texto(imagen) %>" required>
            <div class="form-text">URL http/https o la imagen de ejemplo incluida.</div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-sm-6">
                <label class="form-label" for="inicio">Fecha de inicio</label>
                <input class="form-control" id="inicio" name="fecha_inicio" type="date" min="1000-01-01" max="9999-12-31" value="<%= Web.texto(inicio) %>" required>
            </div>
            <div class="col-sm-6">
                <label class="form-label" for="fin">Fecha de finalización</label>
                <input class="form-control" id="fin" name="fecha_fin" type="date" min="1000-01-01" max="9999-12-31" value="<%= Web.texto(fin) %>" required>
            </div>
            <div class="col-12">
                <label class="form-label" for="premio">Premio en colones (₡)</label>
                <input class="form-control" id="premio" name="premio" type="number" min="0" max="9999999999.99" step="0.01" value="<%= Web.texto(premio) %>" required>
            </div>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-primary">Guardar cambios</button>
            <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet?action=ver&amp;id=<%= torneo.getId() %>">Cancelar</a>
        </div>
    </form>
    <section class="acciones-gestion mt-4 pt-4" aria-label="Administración del torneo">
        <h2 class="h5">Administrar torneo</h2>
        <% if (activo) { %>
        <p class="small text-secondary">Un torneo activo no se puede eliminar. Puedes cancelarlo conservando sus participantes y resultados.</p>
        <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-outline-danger" href="<%= contexto %>/TorneoServlet?action=cancelacion&amp;id=<%= torneo.getId() %>" data-confirmar data-accion="cancelar" data-id="<%= torneo.getId() %>" data-destino="<%= contexto %>/TorneoServlet" data-titulo="¿Cancelar el torneo?" data-mensaje="El torneo <%= Web.texto(torneo.getNombre()) %> dejará de estar activo. Sus participantes, llaves y resultados se conservarán." data-boton="Confirmar cancelación">Cancelar torneo</a>
            <button class="btn btn-outline-danger" disabled>Eliminar torneo</button>
        </div>
        <% } else if (puedeEliminar) { %>
        <p class="small text-secondary">Estado actual: <strong><%= Web.texto(torneo.getEstado()) %></strong>. La eliminación borrará también sus llaves y resultados.</p>
        <a class="btn btn-outline-danger" href="<%= contexto %>/TorneoServlet?action=confirmar&amp;id=<%= torneo.getId() %>" data-confirmar data-accion="eliminar" data-id="<%= torneo.getId() %>" data-destino="<%= contexto %>/TorneoServlet" data-titulo="¿Eliminar el torneo?" data-mensaje="Se eliminarán definitivamente el torneo <%= Web.texto(torneo.getNombre()) %>, sus rondas, llaves y resultados. Los equipos y las cuentas seguirán registrados." data-boton="Eliminar definitivamente">Eliminar torneo</a>
        <% } %>
    </section>
</section>
<script src="<%= contexto %>/assets/torneo-editar.js"></script>
<%@include file="confirmacion.jspf"%>
<%@include file="footer.jspf"%>
