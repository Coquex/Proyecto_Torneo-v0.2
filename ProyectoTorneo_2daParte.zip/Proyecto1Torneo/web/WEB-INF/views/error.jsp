<%@page isErrorPage="true" pageEncoding="UTF-8"%>
<% request.setAttribute("titulo", "Solicitud no completada"); %>
<%@include file="header.jspf"%>
<% Object codigoError = request.getAttribute("jakarta.servlet.error.status_code"); %>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Aviso <%= Web.texto(codigoError) %></p>
    <h1 class="h3">No se pudo completar la solicitud</h1>
    <% if (Integer.valueOf(503).equals(codigoError)) { %>
    <p>No se pudo consultar la base de datos. Revisa que MySQL esté iniciado, que hayas ejecutado el script SQL y que los datos de conexión locales sean correctos.</p>
    <% } else if (Integer.valueOf(403).equals(codigoError)) { %>
    <p>Tu cuenta no tiene permiso para realizar esta acción o el formulario venció. Vuelve a abrir la página e inténtalo nuevamente.</p>
    <% } else if (Integer.valueOf(404).equals(codigoError)) { %>
    <p>La página o el registro solicitado no existe.</p>
    <% } else { %>
    <p>Revisa la dirección y los datos enviados antes de intentarlo nuevamente.</p>
    <% } %>
    <a class="btn btn-primary" href="<%= contexto %>/inicio.jsp">Volver al inicio</a>
    <a class="btn btn-outline-secondary" href="<%= contexto %>/login.jsp">Ir al login</a>
</section>
<%@include file="footer.jspf"%>
