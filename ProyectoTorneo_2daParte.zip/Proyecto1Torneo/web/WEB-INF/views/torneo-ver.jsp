<%@page pageEncoding="UTF-8"%>
<%@page import="java.util.List,my.webapp.torneo.torneo.Torneo,my.webapp.torneo.torneo.Partido,my.webapp.torneo.equipo.Equipo"%>
<% request.setAttribute("titulo", "Llaves del torneo"); %>
<%@include file="header.jspf"%>
<%
    Torneo torneo = (Torneo) request.getAttribute("torneo");
    List<Partido> partidos = (List<Partido>) request.getAttribute("partidos");
    List<Equipo> participantes = (List<Equipo>) request.getAttribute("participantes");
    String[] nombresRondas = {"Ronda preliminar", "Cuartos de final", "Semifinal", "Final"};
%>
<% if ("creado".equals(request.getParameter("estado"))) { %>
<div class="alert alert-success" role="status">Torneo creado correctamente. Las llaves se sortearon y quedaron guardadas.</div>
<% } else if ("actualizado".equals(request.getParameter("estado"))) { %>
<div class="alert alert-success" role="status">Datos del torneo actualizados correctamente. Los participantes y las llaves se conservaron.</div>
<% } else if ("cancelado".equals(request.getParameter("estado"))) { %>
<div class="alert alert-success" role="status">Torneo cancelado. Sus participantes, llaves y resultados se conservaron.</div>
<% } %>
<section class="panel d-flex flex-wrap gap-4 align-items-center mb-4">
    <img class="escudo" src="<%= Web.texto(Web.imagen(contexto, torneo.getImagenUrl())) %>" alt="Imagen del torneo" onerror="this.onerror=null;this.src='<%= contexto %>/assets/imagenes/torneo.svg'">
    <div>
        <p class="etiqueta">Cuadro eliminatorio</p>
        <h1><%= Web.texto(torneo.getNombre()) %></h1>
        <p class="mb-1">Del <%= torneo.getFechaInicio() %> al <%= torneo.getFechaFin() %> · Premio: ₡ <%= torneo.getPremio().toPlainString() %></p>
        <span class="badge text-bg-<%= "ACTIVO".equals(torneo.getEstado()) ? "primary" : "CANCELADO".equals(torneo.getEstado()) ? "danger" : "secondary" %>"><%= Web.texto(torneo.getEstado()) %></span>
        <% if (usuarioActual.isAdmin()) { %>
        <div class="d-flex flex-wrap gap-2 mt-3">
            <a class="btn btn-outline-primary btn-sm" href="<%= contexto %>/TorneoServlet?action=editar&amp;id=<%= torneo.getId() %>">Editar torneo</a>
        </div>
        <% } %>
    </div>
</section>
<h2 class="h4">Llaves del torneo</h2>
<p class="text-secondary">16 participantes · 4 rondas · 15 partidos. <%= "CANCELADO".equals(torneo.getEstado()) ? "El torneo está cancelado y se conserva el cuadro registrado." : "Los equipos de las siguientes rondas se definirán al finalizar sus partidos previos." %></p>
<div class="cuadro-scroll mb-5" tabindex="0" role="region" aria-label="Cuadro eliminatorio con desplazamiento horizontal">
    <div class="cuadro">
    <% for (int r = 1; r <= 4; r++) { %>
        <section class="columna-ronda ronda-<%= r %>" aria-label="<%= nombresRondas[r - 1] %>">
            <h3 class="h6 titulo-ronda"><%= nombresRondas[r - 1] %></h3>
            <div class="partidos-ronda">
            <% for (Partido partido : partidos) { if (partido.getRonda() != r) { continue; } %>
                <div class="puesto-partido">
                    <article class="partido" data-partido-id="<%= partido.getId() %>">
                        <div class="partido-cabecera">Partido <%= partido.getNumero() %> · <%= Web.texto(partido.getEstado()) %></div>
                        <div class="equipo-partido"><span><%= partido.getLocal() == null ? "Por definir" : Web.texto(partido.getLocal()) %></span><strong><%= partido.getGolesLocal() == null ? "—" : partido.getGolesLocal() %></strong></div>
                        <div class="equipo-partido"><span><%= partido.getVisitante() == null ? "Por definir" : Web.texto(partido.getVisitante()) %></span><strong><%= partido.getGolesVisitante() == null ? "—" : partido.getGolesVisitante() %></strong></div>
                    </article>
                </div>
            <% } %>
            </div>
        </section>
    <% } %>
    </div>
</div>
<h2 class="h4 mb-3">Equipos participantes</h2>
<div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-3">
<% for (Equipo equipo : participantes) { %>
    <div class="col"><div class="panel participante d-flex align-items-center gap-3 h-100">
        <img src="<%= Web.texto(Web.imagen(contexto, equipo.getEscudoUrl())) %>" alt="Escudo de <%= Web.texto(equipo.getNombre()) %>" onerror="this.onerror=null;this.src='<%= contexto %>/assets/imagenes/escudo.svg'">
        <span><%= Web.texto(equipo.getNombre()) %></span>
    </div></div>
<% } %>
</div>
<%@include file="footer.jspf"%>
