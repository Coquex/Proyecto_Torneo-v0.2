<%@page pageEncoding="UTF-8"%>
<% request.setAttribute("titulo", "Registrar equipo"); %>
<%@include file="header.jspf"%>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Participación</p>
    <h1 class="h2">Registrar equipo</h1>
    <p class="text-secondary">El equipo quedará pendiente de aprobación por el administrador.</p>
    <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <form method="post" action="<%= contexto %>/EquipoServlet">
        <input type="hidden" name="action" value="registrar">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre del equipo</label>
            <input class="form-control" id="nombre" name="nombre" maxlength="100" value="<%= Web.texto(Web.dato(request, "nombre")) %>" required>
        </div>
        <div class="mb-3">
            <label for="escudo" class="form-label">URL del escudo</label>
            <input class="form-control" id="escudo" name="escudo_url" maxlength="1000" pattern="https?://.+|assets/imagenes/(escudo|torneo)\.svg" value="<%= Web.texto("POST".equals(request.getMethod()) ? Web.dato(request, "escudo_url") : "assets/imagenes/escudo.svg") %>" required aria-describedby="ayuda-escudo">
            <div class="form-text" id="ayuda-escudo">Usa una URL http o https. Para probar puedes utilizar assets/imagenes/escudo.svg.</div>
        </div>
        <div class="mb-3">
            <label for="telefono" class="form-label">Número de teléfono</label>
            <input class="form-control" id="telefono" name="telefono" type="tel" minlength="8" maxlength="20" pattern="[+0-9 \(\)\-]{8,20}" value="<%= Web.texto(Web.dato(request, "telefono")) %>" placeholder="8888-8888" required>
        </div>
        <p class="small text-secondary">Usuario dueño: <strong><%= Web.texto(usuarioActual.getName()) %></strong></p>
        <div class="d-flex gap-2">
            <button class="btn btn-primary">Guardar equipo</button>
            <a class="btn btn-outline-secondary" href="<%= contexto %>/EquipoServlet">Cancelar</a>
        </div>
    </form>
</section>
<%@include file="footer.jspf"%>
