<%@page pageEncoding="UTF-8"%>
<%@page import="my.webapp.torneo.torneo.Torneo"%>
<% request.setAttribute("titulo", "Cancelar torneo"); %>
<%@include file="header.jspf"%>
<% Torneo torneo = (Torneo) request.getAttribute("torneo"); %>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Confirmación</p><h1 class="h3">Cancelar torneo</h1>
    <h2 class="h5 my-3"><%= Web.texto(torneo.getNombre()) %></h2>
    <% if (request.getAttribute("error") != null) { %><div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div><% } %>
    <% if ("ACTIVO".equals(torneo.getEstado())) { %>
    <p>El torneo dejará de estar activo. Sus equipos, llaves y resultados se conservarán.</p>
    <form method="post" action="<%= contexto %>/TorneoServlet" class="d-flex flex-wrap gap-2">
        <input type="hidden" name="action" value="cancelar"><input type="hidden" name="id" value="<%= torneo.getId() %>">
        <input type="hidden" name="confirmacion" value="si"><input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <button class="btn btn-outline-danger">Confirmar cancelación</button>
        <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet?action=editar&amp;id=<%= torneo.getId() %>">Volver</a>
    </form>
    <% } else { %>
    <div class="alert alert-warning">Solo se puede cancelar un torneo activo.</div>
    <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet?action=editar&amp;id=<%= torneo.getId() %>">Volver</a>
    <% } %>
</section>
<%@include file="footer.jspf"%>
