<%@page pageEncoding="UTF-8"%>
<%@page import="my.webapp.torneo.equipo.Equipo"%>
<% request.setAttribute("titulo", "Editar equipo"); %>
<%@include file="header.jspf"%>
<%
    Equipo equipo = (Equipo) request.getAttribute("equipo");
    boolean enviado = "POST".equals(request.getMethod());
    String estadoEquipo = enviado && !equipo.isEstadoBloqueado() ? Web.dato(request, "estado") : equipo.getEstado();
    boolean puedeEliminar = Boolean.TRUE.equals(request.getAttribute("puedeEliminar"));
%>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Administración</p>
    <h1 class="h2">Editar equipo</h1>
    <p class="text-secondary">Revisa los datos del equipo y su estado de participación.</p>
    <% if (request.getAttribute("error") != null) { %><div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div><% } %>
    <form method="post" action="<%= contexto %>/EquipoServlet">
        <input type="hidden" name="action" value="actualizar">
        <input type="hidden" name="id" value="<%= equipo.getId() %>">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="mb-3">
            <label class="form-label" for="nombre">Nombre del equipo</label>
            <input class="form-control" id="nombre" name="nombre" maxlength="100" value="<%= Web.texto(enviado ? Web.dato(request, "nombre") : equipo.getNombre()) %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="escudo">URL del escudo</label>
            <input class="form-control" id="escudo" name="escudo_url" maxlength="1000" pattern="https?://.+|assets/imagenes/(escudo|torneo)\.svg" value="<%= Web.texto(enviado ? Web.dato(request, "escudo_url") : equipo.getEscudoUrl()) %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="telefono">Número de teléfono</label>
            <input class="form-control" id="telefono" name="telefono" type="tel" minlength="8" maxlength="20" pattern="[+0-9 \(\)\-]{8,20}" value="<%= Web.texto(enviado ? Web.dato(request, "telefono") : equipo.getTelefono()) %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="estado">Estado del equipo</label>
            <select class="form-select" id="estado" name="estado" required <%= equipo.isEstadoBloqueado() ? "disabled aria-describedby=\"bloqueo-estado\"" : "" %>>
                <% if (!"APROBADO".equals(estadoEquipo) && !"RECHAZADO".equals(estadoEquipo)) { %><option value="" selected disabled>Selecciona un estado</option><% } %>
                <option value="APROBADO" <%= "APROBADO".equals(estadoEquipo) ? "selected" : "" %>>Aprobado</option>
                <option value="RECHAZADO" <%= "RECHAZADO".equals(estadoEquipo) ? "selected" : "" %>>Rechazado</option>
            </select>
            <% if (equipo.isEstadoBloqueado()) { %>
            <div class="form-text" id="bloqueo-estado">El estado está bloqueado mientras el equipo participe en un torneo activo.</div>
            <% } %>
        </div>
        <p class="small text-secondary">Dueño: <strong><%= Web.texto(equipo.getDueno()) %></strong></p>
        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-primary">Guardar cambios</button>
            <a class="btn btn-outline-secondary" href="<%= contexto %>/EquipoServlet">Volver al listado</a>
        </div>
    </form>
    <section class="acciones-gestion mt-4 pt-4" aria-label="Eliminación del equipo">
        <h2 class="h5">Eliminar equipo</h2>
        <% if (puedeEliminar) { %>
        <p class="small text-secondary">El equipo se eliminará definitivamente de la aplicación.</p>
        <a class="btn btn-outline-danger" href="<%= contexto %>/EquipoServlet?action=confirmar&amp;id=<%= equipo.getId() %>" data-confirmar data-accion="eliminar" data-id="<%= equipo.getId() %>" data-destino="<%= contexto %>/EquipoServlet" data-titulo="¿Eliminar el equipo?" data-mensaje="Se eliminará definitivamente el equipo <%= Web.texto(equipo.getNombre()) %>." data-boton="Eliminar definitivamente">Eliminar equipo</a>
        <% } else { %>
        <p class="small text-secondary"><%= equipo.isEstadoBloqueado() ? "El equipo participa en un torneo activo y no puede eliminarse." : "El equipo pertenece al historial de un torneo. Para eliminarlo, primero elimina ese torneo finalizado o cancelado." %></p>
        <button class="btn btn-outline-danger" disabled>Eliminar equipo</button>
        <% } %>
    </section>
</section>
<%@include file="confirmacion.jspf"%>
<%@include file="footer.jspf"%>
