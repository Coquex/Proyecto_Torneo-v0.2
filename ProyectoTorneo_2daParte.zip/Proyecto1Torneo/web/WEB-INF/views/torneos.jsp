<%@page pageEncoding="UTF-8"%>
<%@page import="java.util.List,my.webapp.torneo.torneo.Torneo"%>
<% request.setAttribute("titulo", "Torneos"); %>
<%@include file="header.jspf"%>
<% List<Torneo> torneos = (List<Torneo>) request.getAttribute("torneos"); %>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div><p class="etiqueta">Competición</p><h1>Torneos</h1><p class="text-secondary mb-0">Consulta los participantes y las llaves del torneo.</p></div>
    <% if (usuarioActual.isAdmin()) { %><a class="btn btn-primary" href="<%= contexto %>/TorneoServlet?action=nuevo">Crear torneo</a><% } %>
</div>
<% if ("eliminado".equals(request.getParameter("estado"))) { %>
<div class="alert alert-success" role="status">Torneo eliminado correctamente. Los equipos siguen registrados y pueden participar en un nuevo torneo.</div>
<% } %>
<% if (torneos.isEmpty()) { %><div class="panel">Todavía no se ha creado ningún torneo.</div><% } %>
<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
<% for (Torneo torneo : torneos) { %>
    <div class="col">
        <article class="panel h-100">
            <img class="imagen-torneo mb-3" src="<%= Web.texto(Web.imagen(contexto, torneo.getImagenUrl())) %>" alt="Imagen de <%= Web.texto(torneo.getNombre()) %>" onerror="this.onerror=null;this.src='<%= contexto %>/assets/imagenes/torneo.svg'">
            <h2 class="h4"><%= Web.texto(torneo.getNombre()) %></h2>
            <p class="mb-1">Inicio: <%= torneo.getFechaInicio() %></p>
            <p class="mb-1">Finalización: <%= torneo.getFechaFin() %></p>
            <p class="mb-2">Premio: ₡ <%= torneo.getPremio().toPlainString() %></p>
            <p><span class="badge text-bg-<%= "ACTIVO".equals(torneo.getEstado()) ? "primary" : "CANCELADO".equals(torneo.getEstado()) ? "danger" : "secondary" %>"><%= Web.texto(torneo.getEstado()) %></span></p>
            <a class="btn btn-outline-primary" href="<%= contexto %>/TorneoServlet?action=ver&amp;id=<%= torneo.getId() %>">Ver llaves y participantes</a>
            <% if (usuarioActual.isAdmin()) { %>
            <div class="d-flex flex-wrap gap-2 mt-3">
                <a class="btn btn-outline-primary btn-sm" href="<%= contexto %>/TorneoServlet?action=editar&amp;id=<%= torneo.getId() %>">Editar</a>
            </div>
            <% } %>
        </article>
    </div>
<% } %>
</div>
<%@include file="footer.jspf"%>
