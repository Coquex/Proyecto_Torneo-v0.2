<%@page pageEncoding="UTF-8"%>
<%@page import="java.util.List,my.webapp.torneo.equipo.Equipo"%>
<% request.setAttribute("titulo", "Equipos"); %>
<%@include file="header.jspf"%>
<%
    List<Equipo> equipos = (List<Equipo>) request.getAttribute("equipos");
    long cantidadAprobados = equipos.stream().filter(e -> "APROBADO".equals(e.getEstado())).count();
%>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div><p class="etiqueta">Participantes</p><h1>Equipos</h1><p class="text-secondary mb-0">Equipos aprobados: <strong><%= cantidadAprobados %></strong></p></div>
    <a class="btn btn-primary" href="<%= contexto %>/EquipoServlet?action=nuevo">Registrar equipo</a>
</div>
<% if (request.getAttribute("error") != null) { %>
    <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
<% } %>
<% if ("registrado".equals(request.getParameter("estado"))) { %>
    <div class="alert alert-success" role="status">Equipo registrado correctamente. Está pendiente de aprobación.</div>
<% } else if ("actualizado".equals(request.getParameter("estado"))) { %>
    <div class="alert alert-success" role="status">Equipo actualizado correctamente.</div>
<% } else if ("eliminado".equals(request.getParameter("estado"))) { %>
    <div class="alert alert-success" role="status">Equipo eliminado definitivamente.</div>
<% } %>
<% if (equipos.isEmpty()) { %><div class="panel">Aún no hay equipos para mostrar.</div><% } %>
<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
<% for (Equipo equipo : equipos) { %>
    <div class="col">
        <article class="panel equipo-card h-100" data-equipo-id="<%= equipo.getId() %>">
            <img class="escudo mb-3" src="<%= Web.texto(Web.imagen(contexto, equipo.getEscudoUrl())) %>" alt="Escudo de <%= Web.texto(equipo.getNombre()) %>" onerror="this.onerror=null;this.src='<%= contexto %>/assets/imagenes/escudo.svg'">
            <h2 class="h5"><%= Web.texto(equipo.getNombre()) %></h2>
            <p class="mb-1">Teléfono: <%= Web.texto(equipo.getTelefono()) %></p>
            <p class="mb-2">Dueño: <%= Web.texto(equipo.getDueno()) %></p>
            <span class="badge text-bg-<%= "APROBADO".equals(equipo.getEstado()) ? "success" : "PENDIENTE".equals(equipo.getEstado()) ? "secondary" : "danger" %>"><%= Web.texto(equipo.getEstado()) %></span>
            <% if (equipo.isEstadoBloqueado()) { %>
                <p class="small mt-2 mb-0">Estado bloqueado por torneo activo.</p>
            <% } %>
            <% if (usuarioActual.isAdmin()) { %>
            <div class="d-flex flex-wrap gap-2 mt-3">
                <% if ("PENDIENTE".equals(equipo.getEstado()) && !equipo.isEstadoBloqueado()) { %>
                <% for (String accion : new String[]{"aprobar", "rechazar"}) { %>
                <form method="post" action="<%= contexto %>/EquipoServlet">
                    <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
                    <input type="hidden" name="action" value="<%= accion %>">
                    <input type="hidden" name="id" value="<%= equipo.getId() %>">
                    <button class="btn btn-sm btn-outline-<%= "aprobar".equals(accion) ? "success" : "danger" %>"><%= "aprobar".equals(accion) ? "Aceptar" : "Rechazar" %></button>
                </form>
                <% } %>
                <% } else { %>
                    <a class="btn btn-sm btn-outline-primary" href="<%= contexto %>/EquipoServlet?action=editar&amp;id=<%= equipo.getId() %>">Editar</a>
                <% } %>
            </div>
            <% } %>
        </article>
    </div>
<% } %>
</div>
<%@include file="footer.jspf"%>
