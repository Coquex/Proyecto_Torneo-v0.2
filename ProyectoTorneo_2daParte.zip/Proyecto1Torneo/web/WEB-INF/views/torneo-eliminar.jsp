<%@page pageEncoding="UTF-8"%>
<%@page import="my.webapp.torneo.torneo.Torneo"%>
<% request.setAttribute("titulo", "Eliminar torneo"); %>
<%@include file="header.jspf"%>
<%
    Torneo torneo = (Torneo) request.getAttribute("torneo");
    boolean puedeEliminar = Boolean.TRUE.equals(request.getAttribute("puedeEliminar"));
%>
<section class="panel formulario mx-auto">
    <p class="etiqueta">Administración</p>
    <h1 class="h2">Eliminar torneo</h1>
    <div class="d-flex align-items-center gap-3 my-4">
        <img class="escudo" src="<%= Web.texto(Web.imagen(contexto, torneo.getImagenUrl())) %>" alt="Imagen del torneo" onerror="this.onerror=null;this.src='<%= contexto %>/assets/imagenes/torneo.svg'">
        <div>
            <h2 class="h4"><%= Web.texto(torneo.getNombre()) %></h2>
            <p class="mb-1">Del <%= torneo.getFechaInicio() %> al <%= torneo.getFechaFin() %></p>
            <p class="mb-0">Estado: <strong><%= Web.texto(torneo.getEstado()) %></strong></p>
        </div>
    </div>
    <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <% if (puedeEliminar) { %>
        <div class="alert alert-warning">
            <strong>¿Deseas eliminar este torneo?</strong>
            <p class="mt-2 mb-0">Se eliminarán el torneo, sus rondas, llaves y resultados. Los equipos y las cuentas seguirán registrados. Esta acción no se puede deshacer.</p>
        </div>
        <form method="post" action="<%= contexto %>/TorneoServlet" class="d-flex flex-wrap gap-2">
            <input type="hidden" name="action" value="eliminar">
            <input type="hidden" name="id" value="<%= torneo.getId() %>">
            <input type="hidden" name="confirmacion" value="si">
            <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
            <button class="btn btn-outline-danger">Confirmar eliminación</button>
            <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet?action=ver&amp;id=<%= torneo.getId() %>">Cancelar</a>
        </form>
    <% } else { %>
        <div class="alert alert-warning">Un torneo activo no se puede eliminar. Primero debe finalizarse o cancelarse.</div>
        <a class="btn btn-outline-secondary" href="<%= contexto %>/TorneoServlet?action=ver&amp;id=<%= torneo.getId() %>">Volver al torneo</a>
    <% } %>
</section>
<%@include file="footer.jspf"%>
