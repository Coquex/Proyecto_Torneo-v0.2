<%@page pageEncoding="UTF-8"%>
<% request.setAttribute("titulo", "Iniciar sesión"); %>
<%@include file="WEB-INF/views/header.jspf"%>
<section class="panel acceso mx-auto">
    <p class="etiqueta">Bienvenido</p>
    <h1 class="h2">Iniciar sesión</h1>
    <p class="text-secondary">Ingresa para registrar equipos y consultar el torneo.</p>
    <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-danger" role="alert"><%= Web.texto(request.getAttribute("error")) %></div>
    <% } %>
    <% if ("registered".equals(request.getParameter("success"))) { %>
        <div class="alert alert-success" role="status">Cuenta registrada correctamente. Ya puedes iniciar sesión.</div>
    <% } %>
    <form method="post" action="<%= contexto %>/LoginServlet">
        <input type="hidden" name="csrf" value="<%= Web.token(session) %>">
        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <input class="form-control" id="email" name="txtemail" type="email" maxlength="254" autocomplete="username" value="<%= Web.texto(Web.dato(request, "txtemail")) %>" required>
        </div>
        <div class="mb-4">
            <label for="password" class="form-label">Contraseña</label>
            <input class="form-control" id="password" name="txtpwd" type="password" maxlength="128" autocomplete="current-password" required>
        </div>
        <button class="btn btn-primary w-100">Ingresar</button>
    </form>
    <p class="mt-4 mb-0">¿Aún no tienes cuenta? <a href="<%= contexto %>/register.jsp">Registrarse</a></p>
</section>
<%@include file="WEB-INF/views/footer.jspf"%>
